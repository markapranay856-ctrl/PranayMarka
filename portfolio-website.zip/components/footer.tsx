export function Footer() {
  return (
    <footer className="relative z-10 border-t border-[var(--slate-border)] px-6 py-8 text-center">
      <p className="font-mono text-xs text-[var(--text-muted)]">
        © 2025 Marka Pranay · Built with{" "}
        <span className="text-[var(--cyber)]">♥</span> · Data tells stories
      </p>
    </footer>
  )
}
