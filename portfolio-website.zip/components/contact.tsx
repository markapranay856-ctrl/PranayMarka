import Link from "next/link"

export function Contact() {
  return (
    <section id="contact" className="relative z-10 px-6 py-24">
      <div className="mx-auto max-w-2xl text-center">
        <div className="mb-3 font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          {"Let's Work Together"}
        </div>
        <h2 className="glow-text mb-4 font-mono text-3xl font-bold text-[var(--cyber)]">
          {"Let's Connect"}
        </h2>
        <p className="mb-12 text-base text-[var(--text-muted)]">
          {"Let's connect to achieve data-driven goals!"}
        </p>

        <div className="flex flex-col justify-center gap-4 sm:flex-row">
          <Link
            href="https://www.linkedin.com/in/marka-pranay/"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2.5 rounded-lg border border-[var(--slate-border)] px-6 py-3.5 font-mono text-sm text-[#c8ddf5] transition-all hover:-translate-y-0.5 hover:border-[var(--cyber)] hover:bg-[rgba(0,245,212,0.05)] hover:text-[var(--cyber)]"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="transition-colors"
            >
              <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
              <rect x="2" y="9" width="4" height="12" />
              <circle cx="4" cy="4" r="2" />
            </svg>
            www.linkedin.com/in/marka-pranay/
          </Link>
          <Link
            href="mailto:markapranay@gmail.com"
            className="group inline-flex items-center gap-2.5 rounded-lg border border-[var(--slate-border)] px-6 py-3.5 font-mono text-sm text-[#c8ddf5] transition-all hover:-translate-y-0.5 hover:border-[var(--cyber)] hover:bg-[rgba(0,245,212,0.05)] hover:text-[var(--cyber)]"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              className="transition-colors"
            >
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
              <polyline points="22,6 12,13 2,6" />
            </svg>
            markapranay@gmail.com
          </Link>
        </div>
      </div>
    </section>
  )
}
