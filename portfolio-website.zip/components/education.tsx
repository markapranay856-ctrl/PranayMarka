const coursework = ["AI Fundamentals", "Machine Learning", "Statistical Analysis", "Data Structures"]

const targetRoles = [
  {
    title: "Data Analyst",
    subtitle: "Insights · Reporting · SQL",
    color: "var(--cyber)",
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--cyber)" strokeWidth="1.5">
        <path d="M3 3v18h18" />
        <circle cx="9" cy="9" r="2" />
        <circle cx="15" cy="6" r="2" />
        <circle cx="12" cy="15" r="2" />
      </svg>
    ),
  },
  {
    title: "Product Analyst",
    subtitle: "Metrics · A/B Testing · UX",
    color: "var(--cyber2)",
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--cyber2)" strokeWidth="1.5">
        <rect x="2" y="3" width="20" height="14" rx="2" />
        <path d="M8 21h8M12 17v4" />
      </svg>
    ),
  },
  {
    title: "BI Analyst",
    subtitle: "Power BI · Dashboards · KPIs",
    color: "var(--ember)",
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="1.5">
        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
      </svg>
    ),
  },
]

export function Education() {
  return (
    <section id="education" className="relative z-10 px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-3 text-center font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          Academic Background
        </div>
        <h2 className="mb-12 text-center font-mono text-3xl font-bold text-[#e8f4ff]">
          Education
        </h2>

        {/* Degree Card */}
        <div className="pulse-border mb-10 rounded-xl border border-[var(--slate-border)] bg-[var(--slate-card)] p-8">
          <div className="flex flex-col items-start gap-6 md:flex-row">
            <div
              className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-xl"
              style={{
                background: "rgba(0,245,212,0.1)",
                border: "1px solid rgba(0,245,212,0.2)",
              }}
            >
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--cyber)" strokeWidth="1.5">
                <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                <path d="M6 12v5c3 3 9 3 12 0v-5" />
              </svg>
            </div>
            <div className="flex-1">
              <div className="mb-2 font-mono text-xs tracking-[0.15em] text-[rgba(0,245,212,0.5)]">
                UNDERGRADUATE DEGREE
              </div>
              <h3 className="mb-1 text-lg font-bold text-[#e8f4ff]">
                B.Tech — Artificial Intelligence & Machine Learning
              </h3>
              <p className="mb-4 text-sm text-[var(--cyber)]">
                Jawaharlal Nehru Technological University, Hyderabad (JNTUH)
              </p>
              <p className="mb-5 text-sm text-[var(--text-muted)]">
                Specialized coursework in machine learning algorithms, deep
                learning fundamentals, statistical analysis, and data
                engineering — directly applied to real-world internship
                projects.
              </p>
              <div className="flex flex-wrap gap-2">
                {coursework.map((tag) => (
                  <span
                    key={tag}
                    className="rounded border border-[rgba(0,245,212,0.2)] bg-[rgba(0,245,212,0.08)] px-2.5 py-1 font-mono text-[0.72rem] text-[var(--cyber)]"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Target Roles */}
        <div>
          <div className="mb-6 text-center font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
            Target Roles
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {targetRoles.map((role) => (
              <div
                key={role.title}
                className="rounded-xl border border-[var(--slate-border)] bg-[var(--slate-card)] p-5 text-center transition-all hover:border-[rgba(0,245,212,0.3)] hover:-translate-y-1"
              >
                <div
                  className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-lg"
                  style={{
                    background: `${role.color}15`,
                    border: `1px solid ${role.color}30`,
                  }}
                >
                  {role.icon}
                </div>
                <div className="mb-1 font-semibold text-[#e8f4ff]">
                  {role.title}
                </div>
                <div className="text-xs text-[var(--text-muted)]">
                  {role.subtitle}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
