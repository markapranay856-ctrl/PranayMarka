"use client"

import { useState } from "react"

const project1Tabs = [
  { id: "setup", label: "01 · Setup" },
  { id: "eda", label: "02 · EDA & Cleaning" },
  { id: "arima", label: "03 · ARIMA" },
  { id: "sarima", label: "04 · SARIMA" },
  { id: "output", label: "05 · Output" },
]

const project1Code: Record<string, string> = {
  setup: `import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_squared_error
import os

# Load dataset
df = pd.read_excel('aapl_2014_2023.csv.xlsx')
df.info()`,

  eda: `# Check missing values
print("Missing values per column:")
df.isnull().sum()

# Handle missing values
df.fillna(method='ffill', inplace=True)
df.fillna(method='bfill', inplace=True)
df.dropna(inplace=True)

# Convert date column to datetime index
df['date'] = pd.to_datetime(df['date'])
df.set_index('date', inplace=True)

# Resample summaries
monthly_open = df['open'].resample('M').mean()
quarter_high = df['high'].resample('Q').max()
daily_close  = df['close'].resample('D').mean()
yearly_low   = df['low'].resample('Y').min()

# Train-test split (80/20)
Train_size = int(len(df) * 0.8)
train = df['open'][:Train_size]
test  = df['open'][Train_size:]`,

  arima: `# Fit ARIMA model (p=5, d=1, q=0)
model     = ARIMA(train, order=(5, 1, 0))
model_fit = model.fit()

# Forecast
forecast  = model_fit.forecast(steps=len(test))

# Evaluate
arima_mse  = mean_squared_error(test, forecast)
ARIMA_RMSE = np.sqrt(arima_mse)
print("ARIMA RMSE:", ARIMA_RMSE)

# Plot
plt.figure(figsize=(10, 6))
plt.plot(train.index, train, marker='*', label='Training Data')
plt.plot(test.index,  test,  marker='*', label='Actual')
plt.plot(test.index,  forecast, marker='*', label='ARIMA Forecast')
plt.legend(loc='upper left')
plt.grid(True)
plt.show()`,

  sarima: `# Fit SARIMA model
model_sarima     = SARIMAX(train, order=(1,1,1),
                          seasonal_order=(1,1,1,12))
model_fit_sarima = model_sarima.fit()

# Forecast
forecast_sarima  = model_fit_sarima.forecast(steps=len(test))

# Evaluate
sarima_mse  = mean_squared_error(test, forecast_sarima)
SARIMA_RMSE = np.sqrt(sarima_mse)
print("SARIMA RMSE:", SARIMA_RMSE)

# Plot
plt.figure(figsize=(10, 6))
plt.plot(train.index, train,           marker='*', label='Training Data')
plt.plot(test.index,  test,            marker='*', label='Actual')
plt.plot(test.index,  forecast_sarima, marker='^', label='SARIMA Forecast')
plt.legend(loc='upper left')
plt.grid(True)
plt.show()`,

  output: `# Build final output dataframe
final_output = pd.DataFrame({
    "Date":              test.index,
    "Actual_Close":      test.values,
    "ARIMA_Prediction":  forecast,
    "SARIMA_Prediction": forecast_sarima
})
final_output["Best_Model"] = final_output.apply(
    lambda x: "ARIMA"
    if abs(x["Actual_Close"] - x["ARIMA_Prediction"])
       < abs(x["Actual_Close"] - x["SARIMA_Prediction"])
    else "SARIMA", axis=1
)
meta_ai = {
    "trend":         "Bearish",
    "reason":        "Supply-demand, macroeconomic factors, market sentiment",
    "seasonality":   "Monthly seasonal patterns observed",
    "error_insight": "ARIMA performs better than SARIMA due to lower error"
}
final_output["Trend_Direction"]  = meta_ai["trend"]
final_output["Reasons"]          = meta_ai["reason"]
final_output["Seasonality_Info"] = meta_ai["seasonality"]
final_output["Model_Insight"]    = meta_ai["error_insight"]
final_output.to_csv("forecasting_arima_sarima.csv", index=False)
print(final_output.head())`,
}

const project2Tabs = [
  { id: "setup", label: "01 · Setup" },
  { id: "clean", label: "02 · Cleaning" },
  { id: "feature", label: "03 · Features" },
  { id: "model", label: "04 · XGBoost" },
  { id: "eval", label: "05 · Evaluation" },
]

const project2Code: Record<string, string> = {
  setup: `import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import accuracy_score, roc_auc_score
from xgboost import XGBClassifier

# Load datasets
customers_churn_data = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")
Transactions         = pd.read_csv("Daily Household Transactions.csv")`,

  clean: `# Check and handle missing values
customers_churn_data.isnull().sum()
Transactions.dropna(axis=0, how='any', subset=['Mode', 'Subcategory'])

# Check duplicates
customers_churn_data.duplicated().sum()

# Convert and fill date column
Transactions['Date'] = pd.to_datetime(Transactions['Date'], errors='coerce')
Transactions['Date'].bfill(inplace=True)

# Add joining & ending dates
customers_churn_data['Joining_date'] = pd.date_range(
    start='2003-09-29', periods=len(customers_churn_data), freq='D')
customers_churn_data['Ending_date']  = pd.date_range(
    end='2023-09-29', periods=len(customers_churn_data), freq='D')`,

  feature: `# Engagement score feature
Transactions['engagement_score'] = (
    Transactions['Amount'] * 30 / Transactions['Amount'].max()
)

# Subscription tenure
customers_churn_data['Subcription_tenure'] = (
    customers_churn_data['Joining_date'] - customers_churn_data['Ending_date']
).abs()

# Sales feature
customers_churn_data['Sales'] = (
    customers_churn_data['MonthlyCharges'] *
    customers_churn_data['Subcription_tenure']
).abs()

# Customer behaviour label
customers_churn_data['customer_behaviour'] = customers_churn_data['Churn']
customers_churn_data.replace({
    'customer_behaviour': {'Yes': 'Interested', 'No': 'Not Interested'}
}, inplace=True)

# Merge datasets
combine_df = pd.concat([Transactions, customers_churn_data], axis=1)
combine_df.dropna(axis=0, how='all', subset=['Date'], inplace=True)`,

  model: `# Label-encode binary columns
le = LabelEncoder()
for col in ['gender', 'Partner', 'Dependents', 'Churn']:
    customers_churn_data[col] = le.fit_transform(customers_churn_data[col])

# One-hot encode multi-category columns
encoded = pd.get_dummies(customers_churn_data,
    columns=['InternetService', 'Contract', 'PaymentMethod'],
    drop_first=True)

# Features & target split
X = encoded.drop(columns=["Churn"])
y = encoded["Churn"]

numeric_cols     = X.select_dtypes(include=['int64', 'float64']).columns
categorical_cols = X.select_dtypes(include=['object']).columns

preprocessor = ColumnTransformer(transformers=[
    ('num', StandardScaler(),                       numeric_cols),
    ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
])

X_train_orig, X_test_orig, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
X_train = preprocessor.fit_transform(X_train_orig)
X_test  = preprocessor.transform(X_test_orig)

# Train XGBoost
model = XGBClassifier(
    n_estimators=100, learning_rate=0.1,
    max_depth=5, random_state=42, eval_metric='logloss'
)
model.fit(X_train, y_train)`,

  eval: `# Predict & evaluate
y_pred        = model.predict(X_test)
y_prob        = model.predict_proba(X_test)
y_prob_class1 = y_prob[:, 1]

accuracy = accuracy_score(y_test, y_pred)
auc      = roc_auc_score(y_test, y_prob_class1)
print("Accuracy:", accuracy)
print("AUC Score:", auc)

# Correlation heatmap
heatmap = combine_df.corr(method='kendall', numeric_only=True)
sns.heatmap(data=heatmap, annot=True, cmap='rainbow')
plt.show()

# Export
combine_df.to_csv("final_dashboard_dataset.csv", index=False)
print("Sample churn probabilities:", y_prob_class1[:10])`,
}

export function CodeSection() {
  return (
    <section id="code" className="relative z-10 px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mb-3 text-center font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          Notebook Source
        </div>
        <h2 className="mb-3 text-center font-mono text-3xl font-bold text-[#e8f4ff]">
          Code
        </h2>
        <p className="mb-14 text-center text-sm text-[var(--text-muted)]">
          Actual Python notebooks · Click tabs to explore
        </p>

        {/* Project 1 Code */}
        <CodePanel
          title="Time Series Forecasting — Apple Stock Market"
          subtitle="PROJECT 01 · NOTEBOOK"
          tag="ARIMA · SARIMA"
          tabs={project1Tabs}
          codeMap={project1Code}
          color="var(--cyber)"
          icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--cyber)" strokeWidth="2">
              <path d="M3 3v18h18" />
              <path d="M18 9l-5 5-4-4-3 3" />
            </svg>
          }
        />

        {/* Project 2 Code */}
        <CodePanel
          title="Customer Churn Predictions — XGBoost Retention Model"
          subtitle="PROJECT 02 · NOTEBOOK"
          tag="XGBoost"
          tabs={project2Tabs}
          codeMap={project2Code}
          color="var(--ember)"
          icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          }
          className="mt-10"
        />
      </div>
    </section>
  )
}

interface CodePanelProps {
  title: string
  subtitle: string
  tag: string
  tabs: { id: string; label: string }[]
  codeMap: Record<string, string>
  color: string
  icon: React.ReactNode
  className?: string
}

function CodePanel({ title, subtitle, tag, tabs, codeMap, color, icon, className }: CodePanelProps) {
  const [activeTab, setActiveTab] = useState(tabs[0].id)

  return (
    <div className={`overflow-hidden rounded-xl border border-[var(--slate-border)] bg-[var(--slate-card)] ${className}`}>
      <div className="flex items-center gap-3 border-b border-[rgba(0,245,212,0.08)] px-6 py-5">
        <div
          className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded"
          style={{ background: `${color}15`, border: `1px solid ${color}30` }}
        >
          {icon}
        </div>
        <div>
          <div className="font-mono text-xs tracking-[0.15em]" style={{ color: `${color}80` }}>
            {subtitle}
          </div>
          <div className="font-bold text-[#e8f4ff]">{title}</div>
        </div>
        <span
          className="ml-auto rounded border px-2.5 py-1 font-mono text-[0.72rem]"
          style={{ borderColor: `${color}50`, color }}
        >
          {tag}
        </span>
      </div>

      <div className="overflow-hidden rounded-none border border-[rgba(0,245,212,0.12)] bg-[#020c18]">
        <div className="flex gap-0 overflow-x-auto border-b border-[rgba(0,245,212,0.1)]">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`whitespace-nowrap border-b-2 bg-transparent px-4 py-2.5 font-mono text-[0.7rem] tracking-[0.08em] transition-colors ${
                activeTab === tab.id
                  ? "border-[var(--cyber)] text-[var(--cyber)]"
                  : "border-transparent text-[var(--text-muted)] hover:text-[var(--cyber)]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <pre className="max-h-[480px] overflow-auto p-6 font-mono text-[0.72rem] leading-relaxed text-[#c8ddf5]">
          <CodeHighlight code={codeMap[activeTab]} />
        </pre>
      </div>
    </div>
  )
}

function CodeHighlight({ code }: { code: string }) {
  // Parse and highlight code with React elements
  const lines = code.split("\n")
  
  return (
    <code>
      {lines.map((line, lineIndex) => (
        <span key={lineIndex}>
          {highlightLine(line)}
          {lineIndex < lines.length - 1 && "\n"}
        </span>
      ))}
    </code>
  )
}

function highlightLine(line: string) {
  // Match keywords
  const keywords = /\b(import|from|as|def|class|return|if|else|for|in|lambda|True|False|None)\b/g
  // Match function calls
  const functions = /\b(\w+)\(/g
  // Match comments
  const comments = /(#.*)/g
  // Match strings
  const strings = /(['"][^'"]*['"])/g
  // Match numbers
  const numbers = /\b(\d+\.?\d*)\b/g
  
  const parts: { text: string; type: string }[] = []
  let lastIndex = 0
  
  // Combined regex for all patterns
  const combinedRegex = /(\b(?:import|from|as|def|class|return|if|else|for|in|lambda|True|False|None)\b)|(\b\w+)\(|(#.*)|(['"][^'"]*['"])|(\b\d+\.?\d*\b)/g
  
  let match
  while ((match = combinedRegex.exec(line)) !== null) {
    // Add text before match
    if (match.index > lastIndex) {
      parts.push({ text: line.slice(lastIndex, match.index), type: "plain" })
    }
    
    if (match[1]) {
      // Keywords
      parts.push({ text: match[1], type: "keyword" })
    } else if (match[2]) {
      // Function call
      parts.push({ text: match[2], type: "function" })
      parts.push({ text: "(", type: "plain" })
    } else if (match[3]) {
      // Comment
      parts.push({ text: match[3], type: "comment" })
    } else if (match[4]) {
      // String
      parts.push({ text: match[4], type: "string" })
    } else if (match[5]) {
      // Number
      parts.push({ text: match[5], type: "number" })
    }
    
    lastIndex = match.index + match[0].length
  }
  
  // Add remaining text
  if (lastIndex < line.length) {
    parts.push({ text: line.slice(lastIndex), type: "plain" })
  }
  
  if (parts.length === 0) {
    return <>{line}</>
  }
  
  return (
    <>
      {parts.map((part, i) => {
        const colors: Record<string, string> = {
          keyword: "#a78bfa",
          function: "#00f5d4",
          comment: "#4a6a8a",
          string: "#ffbe0b",
          number: "#00bbf9",
          plain: "inherit",
        }
        return (
          <span
            key={i}
            style={{ 
              color: colors[part.type],
              fontStyle: part.type === "comment" ? "italic" : "normal"
            }}
          >
            {part.text}
          </span>
        )
      })}
    </>
  )
}
