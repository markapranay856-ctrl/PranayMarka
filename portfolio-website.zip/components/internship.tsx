const tags = ["Python", "SQL", "Power BI", "Excel", "XGBoost", "ARIMA", "SARIMA"]

export function Internship() {
  return (
    <section id="internship" className="relative z-10 px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-3 text-center font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          Work Experience
        </div>
        <h2
          className="mb-12 text-center font-mono text-3xl font-bold"
          style={{ color: "#e8f4ff" }}
        >
          Internship
        </h2>

        <div className="rounded-xl border border-[var(--slate-border)] bg-[var(--slate-card)] p-8 transition-all hover:border-[rgba(0,245,212,0.3)] hover:-translate-y-1">
          <div className="mb-6 flex items-start gap-4">
            <div
              className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg"
              style={{
                background: "rgba(0,245,212,0.1)",
                border: "1px solid rgba(0,245,212,0.2)",
              }}
            >
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="var(--cyber)"
                strokeWidth="1.5"
              >
                <rect x="2" y="7" width="20" height="14" rx="2" />
                <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" />
              </svg>
            </div>
            <div>
              <div className="text-[1.05rem] font-semibold text-[#e8f4ff]">
                Data Science & Analytics Intern
              </div>
              <div className="mt-1 text-sm text-[var(--cyber)]">
                Zideo Development Startup · Bengaluru
              </div>
            </div>
          </div>

          <div
            className="rounded-r-xl border-l-[3px] border-[var(--cyber)] px-8 py-7"
            style={{
              background:
                "linear-gradient(135deg, rgba(0,245,212,0.04), rgba(0,187,249,0.04))",
            }}
          >
            <p className="font-mono text-[0.78rem] uppercase leading-loose tracking-wide text-[#8aabb0]">
              During my internship, where I performed on data cleaning, data
              analysis, and statistical analysis on data, I then explored
              machine learning basics to generate meaningful insights from large
              datasets. I completed my internship in Data Science & Analytics at
              Zideo Development Startup Company in Bangalore. During my
              internship, I undertook two major projects, such as Time Series
              Forecasting with Apple Stock Market Data & Customer Churns &
              Predictions by an XGBoost Model to generate meaningful insights. I
              enhanced my skills in Python, SQL, Power BI, Excel for data
              analysis, data cleaning, and dashboard making to make decisions
              effectively.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {tags.map((tag) => (
              <span
                key={tag}
                className="rounded border border-[rgba(0,245,212,0.2)] bg-[rgba(0,245,212,0.08)] px-2.5 py-1 font-mono text-[0.72rem] tracking-wide text-[var(--cyber)]"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
