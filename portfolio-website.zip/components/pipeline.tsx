const steps = [
  {
    number: "01",
    title: "PREPROCESSING",
    heading: "Data Preprocessing",
    description:
      "Ingesting raw datasets, handling missing values, removing duplicates, feature engineering, and transforming data for ML readiness.",
    tags: ["Pandas", "Python", "NumPy", "EDA"],
    color: "var(--cyber)",
    icon: (
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="var(--cyber)"
        strokeWidth="1.5"
      >
        <path d="M4 7h16M4 12h16M4 17h16" />
      </svg>
    ),
  },
  {
    number: "02",
    title: "INFERENCE ENGINE",
    heading: "Inference Engine",
    description:
      "Building predictive models to generate probabilistic forecasts, churn scores, and trend signals from structured data.",
    tags: ["XGBoost", "ARIMA", "SARIMA", "ML"],
    color: "var(--cyber2)",
    icon: (
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="var(--cyber2)"
        strokeWidth="1.5"
      >
        <circle cx="12" cy="12" r="3" />
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
      </svg>
    ),
  },
  {
    number: "03",
    title: "EXECUTIVE DELIVERY",
    heading: "Executive Delivery",
    description:
      "Translating model outputs into Power BI dashboards, SQL reports, and Excel summaries for C-suite decision-making.",
    tags: ["Power BI", "SQL", "Excel"],
    color: "var(--ember)",
    icon: (
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="var(--ember)"
        strokeWidth="1.5"
      >
        <rect x="2" y="3" width="20" height="14" rx="2" />
        <path d="M8 21h8M12 17v4" />
      </svg>
    ),
  },
]

export function Pipeline() {
  return (
    <section id="skills" className="relative z-10 px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mb-3 text-center font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          Technical Stack
        </div>
        <h2
          className="mb-3 text-center font-mono text-3xl font-bold"
          style={{ color: "#e8f4ff" }}
        >
          Data Pipeline
        </h2>
        <p className="mb-14 text-center text-sm text-[var(--text-muted)]">
          End-to-end workflow from raw data to executive dashboards
        </p>

        <div className="relative grid gap-6 md:grid-cols-3">
          {/* Arrow connectors (desktop only) */}
          <div className="absolute left-1/3 top-1/2 z-10 hidden -translate-y-1/2 items-center md:flex" style={{ width: "calc(33.3% - 24px)", left: "calc(33.3% + 12px)", pointerEvents: "none" }}>
            <div className="h-px flex-1" style={{ background: "linear-gradient(90deg, rgba(0,245,212,0.3), rgba(0,187,249,0.3))" }} />
            <div className="text-[10px]" style={{ color: "rgba(0,245,212,0.4)" }}>▶</div>
          </div>
          <div className="absolute left-2/3 top-1/2 z-10 hidden -translate-y-1/2 items-center md:flex" style={{ width: "calc(33.3% - 24px)", left: "calc(66.6% + 12px)", pointerEvents: "none" }}>
            <div className="h-px flex-1" style={{ background: "linear-gradient(90deg, rgba(0,187,249,0.3), rgba(241,91,181,0.3))" }} />
            <div className="text-[10px]" style={{ color: "rgba(0,187,249,0.4)" }}>▶</div>
          </div>

          {steps.map((step) => (
            <div
              key={step.number}
              className="group relative overflow-hidden rounded-xl border border-[var(--slate-border)] p-7 transition-all hover:border-[rgba(0,245,212,0.25)]"
              style={{
                background: `linear-gradient(135deg, var(--slate-card), rgba(0,245,212,0.03))`,
              }}
            >
              <div
                className="absolute left-0 right-0 top-0 h-0.5 opacity-0 transition-opacity group-hover:opacity-100"
                style={{
                  background: `linear-gradient(90deg, var(--cyber), var(--cyber2))`,
                }}
              />
              <div
                className="mb-4 font-mono text-xs tracking-[0.2em]"
                style={{ color: `${step.color}80` }}
              >
                {step.number} / {step.title}
              </div>
              <div
                className="mb-5 flex h-10 w-10 items-center justify-center rounded-lg"
                style={{
                  background: `${step.color}15`,
                  border: `1px solid ${step.color}30`,
                }}
              >
                {step.icon}
              </div>
              <h3 className="mb-3 text-[1.05rem] font-bold text-[#e8f4ff]">
                {step.heading}
              </h3>
              <p className="mb-5 text-sm leading-relaxed text-[var(--text-muted)]">
                {step.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {step.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded border px-2.5 py-1 font-mono text-[0.72rem] tracking-wide"
                    style={{
                      background: `${step.color}10`,
                      borderColor: `${step.color}30`,
                      color: step.color,
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
