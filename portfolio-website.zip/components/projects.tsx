"use client"

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
} from "recharts"

// Time series data
const tsData = [
  { date: "31 Mar 2022", actual: 177.84, arima: 179.66, sarima: 187.44, arimaErr: -1.82, sarimaErr: -9.6 },
  { date: "01 Apr 2022", actual: 174.03, arima: 179.66, sarima: 187.5, arimaErr: -5.63, sarimaErr: -13.47 },
  { date: "04 Apr 2022", actual: 174.57, arima: 179.66, sarima: 187.4, arimaErr: -5.09, sarimaErr: -12.83 },
  { date: "05 Apr 2022", actual: 177.5, arima: 179.66, sarima: 187.54, arimaErr: -2.16, sarimaErr: -10.04 },
  { date: "06 Apr 2022", actual: 172.36, arima: 179.66, sarima: 187.92, arimaErr: -7.3, sarimaErr: -15.56 },
  { date: "07 Apr 2022", actual: 171.16, arima: 179.66, sarima: 187.82, arimaErr: -8.5, sarimaErr: -16.66 },
  { date: "08 Apr 2022", actual: 171.78, arima: 179.66, sarima: 188.1, arimaErr: -7.88, sarimaErr: -16.32 },
]

// Customer churn data
const customerData = [
  { id: "C001", engagement: 5.4, tenure: "3 months", fragmentation: "High", churnProb: 87, risk: "Critical", recommendation: "Retention Call" },
  { id: "C002", engagement: 21.7, tenure: "36 months", fragmentation: "Low", churnProb: 12, risk: "Low", recommendation: "Loyalty Rewards" },
  { id: "C003", engagement: 11.2, tenure: "12 months", fragmentation: "Medium", churnProb: 58, risk: "Medium", recommendation: "Email Campaign" },
]

const riskDistribution = [
  { name: "Low Risk (C002)", value: 33.33, color: "#00f5d4" },
  { name: "Medium Risk (C003)", value: 33.33, color: "#ffbe0b" },
  { name: "Critical Risk (C001)", value: 33.33, color: "#f15bb5" },
]

const scatterData = [
  { x: 5.4, y: 0.87, name: "C001 — Critical", fill: "#f15bb5" },
  { x: 21.7, y: 0.12, name: "C002 — Low", fill: "#00f5d4" },
  { x: 11.2, y: 0.58, name: "C003 — Medium", fill: "#ffbe0b" },
]

export function Projects() {
  return (
    <section id="projects" className="relative z-10 px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mb-3 text-center font-mono text-[0.68rem] uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          Featured Work
        </div>
        <h2 className="mb-3 text-center font-mono text-3xl font-bold text-[#e8f4ff]">
          Projects
        </h2>
        <p className="mb-14 text-center text-sm text-[var(--text-muted)]">
          Built with real datasets · STAR Methodology
        </p>

        {/* Project 1: Time Series */}
        <div className="mb-10 rounded-xl border border-[var(--slate-border)] bg-[var(--slate-card)] p-8 transition-all hover:border-[rgba(0,245,212,0.3)]">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded" style={{ background: "rgba(0,245,212,0.1)", border: "1px solid rgba(0,245,212,0.2)" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--cyber)" strokeWidth="2">
                <path d="M3 3v18h18" />
                <path d="M18 9l-5 5-4-4-3 3" />
              </svg>
            </div>
            <div>
              <div className="font-mono text-xs tracking-[0.15em] text-[rgba(0,245,212,0.5)]">PROJECT 01</div>
              <h3 className="text-lg font-bold text-[#e8f4ff]">Time Series Forecasting — Apple Stock Market</h3>
            </div>
            <span className="ml-auto rounded border border-[rgba(0,245,212,0.2)] bg-[rgba(0,245,212,0.08)] px-2.5 py-1 font-mono text-[0.72rem] text-[var(--cyber)]">
              ARIMA · SARIMA
            </span>
          </div>

          {/* STAR Methodology */}
          <div className="mb-8 grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <StarItem label="Situation" text="During my internship, I took the Apple stock market dataset to identify future trends, seasonal information, model insights, and reasons based on past movements." />
              <StarItem label="Task" text="Handle missing values, remove duplicates, terminate null values, convert date columns into index format, and implement ARIMA & SARIMA time-series models." />
            </div>
            <div className="space-y-4">
              <StarItem label="Action" text="Conducted EDA, cleaned the dataset, converted date columns into indexes, and implemented ARIMA & SARIMA forecasting models to generate predictions, trends, and seasonality insights." />
              <StarItem label="Result" text="Developed forecasting models and dashboards generating trend predictions, seasonal insights, and model-based reasons to support stakeholders in data-driven decision-making." />
            </div>
          </div>

          {/* Metrics */}
          <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
            <MetricPill value="-8.09K" label="ARIMA Over-est. Risk" color="#f15bb5" />
            <MetricPill value="-23.37K" label="SARIMA Over-est. Risk" color="#f15bb5" />
            <MetricPill value="Bearish" label="Trend Direction" color="#ffbe0b" />
            <MetricPill value="Monthly" label="Seasonality Pattern" color="var(--cyber)" />
          </div>

          {/* Chart */}
          <div className="mb-6 rounded-lg border border-[var(--slate-border)] bg-[var(--slate-card)] p-4">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-[#c8ddf5]">Actual vs ARIMA vs SARIMA Forecast</span>
              <span className="rounded border border-[rgba(0,245,212,0.2)] bg-[rgba(0,245,212,0.08)] px-2 py-0.5 font-mono text-xs text-[var(--cyber)]">
                Mar–Apr 2022 · Apple Stock
              </span>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={tsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,48,80,0.4)" />
                <XAxis dataKey="date" tick={{ fill: "#5a7a9a", fontSize: 10, fontFamily: "Space Mono" }} />
                <YAxis tick={{ fill: "#5a7a9a", fontSize: 10, fontFamily: "Space Mono" }} tickFormatter={(v) => `$${v}`} domain={[165, 195]} />
                <Tooltip contentStyle={{ background: "#0f1f38", border: "1px solid rgba(0,245,212,0.3)", borderRadius: 8, color: "#e8f4ff" }} />
                <Legend wrapperStyle={{ fontFamily: "Space Mono", fontSize: 11 }} />
                <Line type="monotone" dataKey="actual" name="Actual Close ($)" stroke="#00f5d4" strokeWidth={2.5} dot={{ fill: "#00f5d4", r: 4 }} />
                <Line type="monotone" dataKey="arima" name="ARIMA Prediction" stroke="#00bbf9" strokeWidth={2} strokeDasharray="6 3" dot={{ fill: "#00bbf9", r: 3 }} />
                <Line type="monotone" dataKey="sarima" name="SARIMA Prediction" stroke="#a78bfa" strokeWidth={2} strokeDasharray="4 4" dot={{ fill: "#a78bfa", r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Data Table */}
          <div className="rounded-lg border border-[var(--slate-border)] bg-[var(--slate-card)] p-4">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-[#c8ddf5]">Model Prediction Breakdown</span>
              <span className="rounded border border-[rgba(0,245,212,0.2)] bg-[rgba(0,245,212,0.08)] px-2 py-0.5 font-mono text-xs text-[var(--cyber)]">
                Live Dataset
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse font-mono text-[0.82rem]">
                <thead>
                  <tr>
                    {["Date", "Actual Close ($)", "ARIMA Pred ($)", "SARIMA Pred ($)", "ARIMA Error", "SARIMA Error", "Trend"].map((h) => (
                      <th key={h} className="border-b border-[var(--slate-border)] p-2 text-left text-[0.65rem] uppercase tracking-[0.1em] text-[var(--cyber)]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tsData.map((row) => (
                    <tr key={row.date} className="hover:bg-[rgba(0,245,212,0.03)]">
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 text-[#c8ddf5]">{row.date}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 font-semibold text-[#e8f4ff]">${row.actual.toFixed(2)}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 text-[var(--cyber2)]">${row.arima.toFixed(2)}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 text-[#a78bfa]">${row.sarima.toFixed(2)}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2" style={{ color: getErrorColor(row.arimaErr) }}>{row.arimaErr.toFixed(2)}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2" style={{ color: getErrorColor(row.sarimaErr) }}>{row.sarimaErr.toFixed(2)}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 font-mono text-[0.7rem] text-[#f15bb5]">↓ BEARISH</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Project 2: Customer Churn */}
        <div className="rounded-xl border border-[var(--slate-border)] bg-[var(--slate-card)] p-8 transition-all hover:border-[rgba(241,91,181,0.3)]">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded" style={{ background: "rgba(241,91,181,0.1)", border: "1px solid rgba(241,91,181,0.2)" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
            <div>
              <div className="font-mono text-xs tracking-[0.15em] text-[rgba(241,91,181,0.5)]">PROJECT 02</div>
              <h3 className="text-lg font-bold text-[#e8f4ff]">Customer Churn Predictions — XGBoost Retention Model</h3>
            </div>
            <span className="ml-auto rounded border border-[rgba(241,91,181,0.3)] bg-[rgba(241,91,181,0.08)] px-2.5 py-1 font-mono text-[0.72rem] text-[var(--ember)]">
              XGBoost
            </span>
          </div>

          {/* STAR Methodology */}
          <div className="mb-8 grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <StarItem label="Situation" text="Worked on transactions and customer churn sales datasets to identify high-risk retention customers and analyse behaviour, engagement, and subscription tenure." color="var(--ember)" />
              <StarItem label="Task" text="Handle missing values, engineer features such as engagement score and subscription tenure, eliminate NaN/null values, then implement XGBoost for churn probability prediction." color="var(--ember)" />
            </div>
            <div className="space-y-4">
              <StarItem label="Action" text="Conducted EDA, evaluated XGBoost using Recall, Precision, Accuracy, and F1-Score, then gathered high-risk retentions, engagement scores, and customer behaviour analysis." color="var(--ember)" />
              <StarItem label="Result" text="Created a dashboard displaying high-risk retentions, engagement scores, subscription tenure, and XGBoost probability recommendations to support sales growth and future analysis." color="var(--ember)" />
            </div>
          </div>

          {/* Customer Table */}
          <div className="mb-6 rounded-lg border border-[var(--slate-border)] bg-[var(--slate-card)] p-4">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-[#c8ddf5]">Customer Risk Analysis — XGBoost Output</span>
              <span className="rounded border border-[rgba(241,91,181,0.3)] bg-[rgba(241,91,181,0.08)] px-2 py-0.5 font-mono text-xs text-[var(--ember)]">
                Live Dataset · 3 Records
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse font-mono text-[0.82rem]">
                <thead>
                  <tr>
                    {["Customer ID", "Engagement Score", "Subscription Tenure", "Fragmentation", "Churn Probability", "Risk Level", "Recommendation"].map((h) => (
                      <th key={h} className="border-b border-[var(--slate-border)] p-2 text-left text-[0.65rem] uppercase tracking-[0.1em] text-[var(--cyber)]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {customerData.map((c) => (
                    <tr key={c.id} className="hover:bg-[rgba(0,245,212,0.03)]">
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 font-bold text-[#e8f4ff]">{c.id}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 text-[#9ab5d0]">{c.engagement}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 text-[#9ab5d0]">{c.tenure}</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2" style={{ color: getFragColor(c.fragmentation) }}>{c.fragmentation} Fragmentation</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2 font-bold" style={{ color: getRiskColor(c.risk) }}>{c.churnProb}%</td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2"><RiskBadge risk={c.risk} /></td>
                      <td className="border-b border-[rgba(26,48,80,0.5)] p-2" style={{ color: getRiskColor(c.risk) }}>{c.recommendation}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Charts */}
          <div className="mb-6 grid gap-5 md:grid-cols-2">
            <div className="rounded-lg border border-[var(--slate-border)] bg-[var(--slate-card)] p-4">
              <div className="mb-4 text-sm font-semibold text-[#c8ddf5]">Risk Level Distribution</div>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={riskDistribution} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" paddingAngle={2}>
                    {riskDistribution.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} stroke={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: "#0f1f38", border: "1px solid rgba(241,91,181,0.3)", borderRadius: 8, color: "#e8f4ff" }} />
                  <Legend wrapperStyle={{ fontFamily: "Space Mono", fontSize: 10 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="rounded-lg border border-[var(--slate-border)] bg-[var(--slate-card)] p-4">
              <div className="mb-4 text-sm font-semibold text-[#c8ddf5]">Engagement Score vs Churn Probability</div>
              <ResponsiveContainer width="100%" height={200}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,48,80,0.4)" />
                  <XAxis type="number" dataKey="x" name="Engagement" domain={[0, 30]} tick={{ fill: "#5a7a9a", fontSize: 10 }} />
                  <YAxis type="number" dataKey="y" name="Churn" domain={[0, 1]} tick={{ fill: "#5a7a9a", fontSize: 10 }} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} />
                  <Tooltip contentStyle={{ background: "#0f1f38", border: "1px solid rgba(241,91,181,0.3)", borderRadius: 8, color: "#e8f4ff" }} formatter={(value: number, name: string) => [name === "x" ? value : `${(value * 100).toFixed(0)}%`, name === "x" ? "Engagement" : "Churn"]} />
                  {scatterData.map((point) => (
                    <Scatter key={point.name} name={point.name} data={[point]} fill={point.fill}>
                      <Cell fill={point.fill} />
                    </Scatter>
                  ))}
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <MetricPill value="33.33%" label="Low Risk" color="var(--cyber)" centered />
            <MetricPill value="33.33%" label="Medium Risk" color="#ffbe0b" centered />
            <MetricPill value="33.33%" label="Critical Risk" color="var(--ember)" centered />
          </div>
        </div>
      </div>
    </section>
  )
}

function StarItem({ label, text, color = "var(--cyber)" }: { label: string; text: string; color?: string }) {
  return (
    <div>
      <div className="mb-1 font-mono text-[0.7rem] uppercase tracking-[0.2em]" style={{ color, opacity: 0.7 }}>
        ▸ {label}
      </div>
      <p className="text-sm leading-relaxed" style={{ color: "#7a9aba" }}>{text}</p>
    </div>
  )
}

function MetricPill({ value, label, color, centered }: { value: string; label: string; color: string; centered?: boolean }) {
  return (
    <div className={`rounded-lg border border-[rgba(0,245,212,0.18)] bg-[rgba(0,245,212,0.07)] p-3 font-mono ${centered ? "text-center" : ""}`}>
      <div className="text-xl font-bold" style={{ color }}>{value}</div>
      <div className="mt-0.5 text-[0.65rem] uppercase tracking-[0.1em] text-[var(--text-muted)]">{label}</div>
    </div>
  )
}

function RiskBadge({ risk }: { risk: string }) {
  const styles: Record<string, { bg: string; border: string; color: string }> = {
    Low: { bg: "rgba(0,245,212,0.1)", border: "rgba(0,245,212,0.3)", color: "var(--cyber)" },
    Medium: { bg: "rgba(255,190,11,0.1)", border: "rgba(255,190,11,0.3)", color: "#ffbe0b" },
    Critical: { bg: "rgba(241,91,181,0.1)", border: "rgba(241,91,181,0.3)", color: "var(--ember)" },
  }
  const s = styles[risk]
  return (
    <span className="rounded px-2 py-1 text-xs font-bold" style={{ background: s.bg, border: `1px solid ${s.border}`, color: s.color }}>
      {risk} Risk
    </span>
  )
}

function getErrorColor(v: number) {
  return v < -7 ? "#f15bb5" : v < -3 ? "#ffbe0b" : "#00f5d4"
}

function getRiskColor(risk: string) {
  return risk === "Critical" ? "#f15bb5" : risk === "Medium" ? "#ffbe0b" : "#00f5d4"
}

function getFragColor(frag: string) {
  return frag === "High" ? "#f15bb5" : frag === "Medium" ? "#ffbe0b" : "#00f5d4"
}
