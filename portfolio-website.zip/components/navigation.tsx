"use client"

import Link from "next/link"

const navLinks = [
  { href: "#hero", label: "Home" },
  { href: "#skills", label: "Pipeline" },
  { href: "#internship", label: "Internship" },
  { href: "#projects", label: "Projects" },
  { href: "#code", label: "Code" },
  { href: "#education", label: "Education" },
  { href: "#contact", label: "Contact" },
]

export function Navigation() {
  return (
    <nav className="fixed left-0 right-0 top-0 z-50 border-b border-[var(--slate-border)] bg-[rgba(5,13,26,0.85)] backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <span className="font-mono text-sm font-bold tracking-widest text-[var(--cyber)]">
          MP<span className="text-slate-500">_DA</span>
        </span>
        <div className="hidden gap-8 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-xs uppercase tracking-[0.12em] text-[var(--text-muted)] transition-colors hover:text-[var(--cyber)]"
            >
              {link.label}
            </Link>
          ))}
        </div>
        <span className="rounded border border-[rgba(0,245,212,0.2)] bg-[rgba(0,245,212,0.08)] px-2.5 py-1 font-mono text-xs tracking-wide text-[var(--cyber)]">
          Open to Work
        </span>
      </div>
    </nav>
  )
}
