"use client"

import Image from "next/image"
import Link from "next/link"

export function Hero() {
  return (
    <section
      id="hero"
      className="relative z-10 flex min-h-screen items-center justify-center px-6 pt-20"
    >
      <div className="mx-auto max-w-4xl text-center">
        {/* Profile Photo */}
        <div className="fade-up mb-8 flex justify-center">
          <div className="relative h-40 w-40">
            <div
              className="profile-glow absolute -inset-[3px] rounded-full"
              style={{
                background:
                  "linear-gradient(135deg, var(--cyber), var(--cyber2), var(--ember))",
              }}
            />
            <Image
              src="/profile.jpg"
              alt="Marka Pranay"
              width={160}
              height={160}
              className="relative z-10 rounded-full border-[3px] border-[var(--slate-deep)] object-cover object-top"
              priority
            />
          </div>
        </div>

        <div className="fade-up mb-8 font-mono text-xs uppercase tracking-[0.25em] text-[var(--cyber)] opacity-60">
          Data Analyst · AI/ML Graduate · Fresher
        </div>

        <h1
          className="fade-up delay-1 mb-4 font-mono text-4xl font-bold leading-tight md:text-6xl"
          style={{ color: "#e8f4ff" }}
        >
          Marka <span className="glow-text text-[var(--cyber)]">Pranay</span>
        </h1>

        <p className="fade-up delay-2 mb-6 font-mono text-base tracking-wide text-[var(--cyber2)] md:text-lg">
          Transforming Fragmented Data into Executive Intelligence
          <span className="cursor">_</span>
        </p>

        <p
          className="fade-up delay-3 mx-auto mb-10 max-w-2xl text-base leading-relaxed"
          style={{ color: "#7a9aba" }}
        >
          Hi, my name is Marka Pranay. I hold a{" "}
          <span className="font-medium" style={{ color: "#c8ddf5" }}>
            Bachelor of Technology (B.Tech) in Artificial Intelligence and
            Machine Learning
          </span>{" "}
          from JNTUH University, and I am highly motivated to leverage my
          technical foundation in an entry-level Data Analyst position. I excel
          at uncovering hidden insights from complex data streams and
          translating them into clear visual formats to support effective
          organizational decision-making.
        </p>

        <div className="fade-up delay-4 flex flex-wrap justify-center gap-3">
          <Link
            href="#projects"
            className="rounded-lg bg-[var(--cyber)] px-7 py-3 text-sm font-semibold text-[#050d1a] transition-all hover:opacity-90"
          >
            View Projects
          </Link>
          <Link
            href="#contact"
            className="rounded-lg border border-[var(--slate-border)] px-7 py-3 text-sm font-semibold text-[#c8ddf5] transition-all hover:border-[var(--cyber)] hover:text-[var(--cyber)]"
          >
            Get in Touch
          </Link>
        </div>

        {/* Mini metrics */}
        <div className="fade-up delay-4 mx-auto mt-14 grid max-w-md grid-cols-3 gap-4">
          <MetricCard value="3" label="Customers Analyzed" />
          <MetricCard value="7" label="Stock Forecasts" />
          <MetricCard value="2" label="ML Models" />
        </div>
      </div>
    </section>
  )
}

function MetricCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-lg border border-[rgba(0,245,212,0.18)] bg-[rgba(0,245,212,0.07)] p-3 text-center font-mono">
      <div className="text-xl font-bold text-[var(--cyber)]">{value}</div>
      <div className="mt-0.5 text-[0.65rem] uppercase tracking-[0.1em] text-[var(--text-muted)]">
        {label}
      </div>
    </div>
  )
}
