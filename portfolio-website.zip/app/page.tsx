import { Navigation } from "@/components/navigation"
import { Hero } from "@/components/hero"
import { Pipeline } from "@/components/pipeline"
import { Internship } from "@/components/internship"
import { Projects } from "@/components/projects"
import { CodeSection } from "@/components/code-section"
import { Education } from "@/components/education"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="grid-bg relative">
      {/* Ambient orbs */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />

      <Navigation />
      <Hero />
      <Divider />
      <Pipeline />
      <Divider />
      <Internship />
      <Divider />
      <Projects />
      <Divider />
      <CodeSection />
      <Divider />
      <Education />
      <Divider />
      <Contact />
      <Footer />
    </main>
  )
}

function Divider() {
  return (
    <div
      className="mx-auto h-px max-w-4xl px-6"
      style={{
        background:
          "linear-gradient(90deg, transparent, var(--slate-border), transparent)",
      }}
    />
  )
}
