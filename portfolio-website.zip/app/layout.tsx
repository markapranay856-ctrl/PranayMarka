import type { Metadata, Viewport } from "next"
import { DM_Sans, Space_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-dm-sans",
  display: "swap",
})

const spaceMono = Space_Mono({
  weight: ["400", "700"],
  subsets: ["latin"],
  variable: "--font-space-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Marka Pranay | Data Analyst Portfolio",
  description:
    "Data Analyst & AI/ML Graduate portfolio showcasing time series forecasting, customer churn predictions, and data visualization projects.",
  keywords: [
    "Data Analyst",
    "AI/ML",
    "Machine Learning",
    "Python",
    "SQL",
    "Power BI",
    "XGBoost",
    "ARIMA",
    "SARIMA",
  ],
  authors: [{ name: "Marka Pranay" }],
}

export const viewport: Viewport = {
  themeColor: "#050d1a",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body
        className={`${dmSans.variable} ${spaceMono.variable} font-sans antialiased`}
      >
        {children}
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
